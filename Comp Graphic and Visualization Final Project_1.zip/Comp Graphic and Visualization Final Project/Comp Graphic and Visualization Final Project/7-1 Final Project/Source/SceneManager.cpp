///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include "ViewManager.h"

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/**************************************************************
* LoadSceneTextures() 
*
*  This method is used for preparing the 3D scene by loading the
* textures in memory to support the 3D scene rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// load the textures for the 3D scene
	bool bReturn = false;

	// load the texture for the sphere
	bReturn = CreateGLTexture(
		"../../Utilities/textures/balloon_texture2.jpg", "sphere");

	// load the texture for the cone
	bReturn = CreateGLTexture(
		"../../Utilities/textures/balloon_texture2.jpg", "cone");

	// load the texture for the ground plane
	bReturn = CreateGLTexture(
		"../../Utilities/textures/sand_texture.jpg", "plane");

	// load the texture for the box
	bReturn = CreateGLTexture(
		"../../Utilities/textures/basket_texture.jpg", "box");

	// load the texture for the pyramids
	bReturn = CreateGLTexture(
		"../../Utilities/textures/pyramid_texture1.jpg", "pyramid");

	// after the texture image data is loaded into memory,
	// bind the textures to the OpenGL texture slots in memory
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();

	// define the materials for the 3D scene
	DefineObjectMaterials();

	// set up the lights for the 3D scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadPyramid4Mesh();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for defining the materials for the
 *  3D scene by setting the ambient, diffuse, and specular
 *  values for each material.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// define the material for the ground plane
	OBJECT_MATERIAL sandMaterial;
	sandMaterial.ambientColor = glm::vec3(0.76f, 0.7f, 0.5f);
	sandMaterial.ambientStrength = 0.5f;
	sandMaterial.diffuseColor = glm::vec3(0.45f, 0.38f, 0.32f);
	sandMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	sandMaterial.shininess = 2.0f;
	sandMaterial.tag = "sand";

	m_objectMaterials.push_back(sandMaterial);

	// define the material for the sphere and cone of the hot air balloon
	OBJECT_MATERIAL balloonMaterial;
	balloonMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	balloonMaterial.ambientStrength = 0.5f;
	balloonMaterial.diffuseColor = glm::vec3(0.65f, 0.65f, 0.65f);
	balloonMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	balloonMaterial.shininess = 8.0f;
	balloonMaterial.tag = "balloon";

	m_objectMaterials.push_back(balloonMaterial);

	// define the material for the box of the hot air balloon
	OBJECT_MATERIAL basketMaterial;
	basketMaterial.ambientColor = glm::vec3(0.54f, 0.43f, 0.33f);
	basketMaterial.ambientStrength = 0.5f;
	basketMaterial.diffuseColor = glm::vec3(0.76f, 0.6f, 0.42f);
	basketMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.08f);
	basketMaterial.shininess = 5.0f;
	basketMaterial.tag = "basket";

	m_objectMaterials.push_back(basketMaterial);

	// define the material for the ground plane
	OBJECT_MATERIAL pyramidMaterial;
	pyramidMaterial.ambientColor = glm::vec3(0.12f, 0.1f, 0.08f);
	pyramidMaterial.ambientStrength = 0.5f;
	pyramidMaterial.diffuseColor = glm::vec3(0.45f, 0.38f, 0.32f);
	pyramidMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	pyramidMaterial.shininess = 3.0f;
	pyramidMaterial.tag = "pyramid";

	m_objectMaterials.push_back(pyramidMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for setting up the lights for the
 *  3D scene by setting the ambient, diffuse, and specular
 *  values for each light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setVec3Value("lightSources[0].position", 10.0f, 5.0f, 20.0f);
	m_pShaderManager->setVec3Value("lightSources[0].direction", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.02f, 0.01f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.9f, 0.45f, 0.15f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.6f, 0.3f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);

	m_pShaderManager->setVec3Value("lightSources[1].position", 5.0f, 20.0f, 15.0f);
	m_pShaderManager->setVec3Value("lightSources[1].direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.02f, 0.03f, 0.06f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.15f, 0.25f, 0.45f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.0f, 0.0f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.05f);

	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// Plane Mesh - this mesh is used for the ground plane in the 3D scene
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(22.0f, 0.0f, 12.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("plane");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("sand");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** Sphere Mesh - this mesh is used for the top half of the hot air balloon. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.2f, 1.5f, 2.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -5.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.0f, 10.5f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("sphere");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("balloon");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** Cone Mesh - this mesh is used for the bottom half of the hot air balloon. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.95f, 1.8f, 1.95f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 1.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.055f, 9.81f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("cone");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("balloon");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** Box Mesh - this mesh is used for the basket of the hot air balloon. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.4f, 0.4f, 0.4f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 6.0f;
	YrotationDegrees = -35.0f;
	ZrotationDegrees = 1.8f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.055f, 7.7f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("box");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("basket");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** 4-sided Pyramid Mesh 1 - this mesh is used for the first pyramid. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(8.0f, 5.5f, 8.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 60.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.7f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("pyramid");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("pyramid");

	// draw the mesh with the transformation values
	m_basicMeshes->DrawPyramid4Mesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** 4-sided Pyramid Mesh 2 - this mesh is used for the second pyramid. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(8.5f, 7.0f, 8.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 60.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.5f, 3.5f, -4.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("pyramid");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("pyramid");

	// draw the mesh with the transformation values
	m_basicMeshes->DrawPyramid4Mesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** 4-sided Pyramid Mesh 3 - this mesh is used for the third pyramid. ***/
	/********************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.0f, 2.0f, 3.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 60.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.5f, 1.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture into the shader for the drawn mesh
	SetShaderTexture("pyramid");

	// set the material into the shader for the drawn mesh
	SetShaderMaterial("pyramid");

	// draw the mesh with the transformation values
	m_basicMeshes->DrawPyramid4Mesh();
	/****************************************************************/
}
